﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoticeBoard
{
    public partial class EventForm : Form
    {
       
        public EventForm()
        {
            InitializeComponent();
        }

        public bool AddEvent { get; set; }
        public Events Event { get; set; }



        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (AddEvent) { Event = new Events(); }
            Event.EventTitle = Convert.ToString(txtEventTitle.Text);
            Event.EventText = txtEventDetails.Text;
            Event.EventLocation = txtEventLocation.Text;
            Event.DatePosted = dtpDateSubmitted.Value = DateTime.Today;
            Event.EventHost = txtEventHost.Text;
            Event.EventType = txtEventType.Text;
            Event.HostContact = txtHostContactInfo.Text;
            this.DialogResult = DialogResult.OK;


            Event = new Events();
          
            Event.EventTitle = Convert.ToString(txtEventTitle.Text);
            Event.EventText = txtEventDetails.Text;
            Event.EventLocation = txtEventLocation.Text;
            Event.DatePosted = dtpDateSubmitted.Value = DateTime.Today;
            Event.EventHost = txtEventHost.Text;
            Event.EventType = txtEventType.Text;
            Event.HostContact = txtHostContactInfo.Text;
            this.DialogResult = DialogResult.OK;


          
        }


        private void EventForm_Load(object sender, EventArgs e)
        {
            if (AddEvent)
            {
                this.Text = "add new event";

            }
            else
            {
                this.Text = "edit event";
                Display_Events2();
            }
           
        }

        private void Display_Events2()
        {
            

            txtEventTitle.Text = Event.EventTitle;
            txtEventDetails.Text = Event.EventText;
            txtEventLocation.Text = Event.EventLocation;
            dtpDateSubmitted.Value = Event.DatePosted;
            txtEventHost.Text = Event.EventHost;
            txtEventType.Text = Event.EventType;
            txtHostContactInfo.Text = Event.HostContact;



        }

    }

}
