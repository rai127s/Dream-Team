﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace NoticeBoard
{
    public partial class Board : Form
    {
        List<Notices> NoticeList = new List<Notices>();
        List<Events> events = new List<Events>();
        List<MemberInfo> MemberList = new List<MemberInfo>();

        //curfile is used to write to a text file called evente.txt stored in the bin
        string curFile = "Events.txt";
        string curFile1 = "Notice.txt";
        public Board()
        {
            InitializeComponent();
        }
        private Notices SelectedNotice;

        //selectedEvents finds the event on the datagridview that the user chose
        private Events selectedEvent;

        private void DisplayEvents()
        {


            dataGridView1.DataSource = null;

            dataGridView1.DataSource = events;


        }


        private void Form1_Load(object sender, EventArgs e)
        {
            Notices n = new Notices(1, "Clean Toilets", "Clean the toilets or i will fire everyone :)", DateTime.Now.Date, DateTime.Now.Date, 10, "Warning", "James");
            Notices n1 = new Notices(2, "Rotten Food", "Stop leaving expired food in the fridge", DateTime.Now.Date, DateTime.Now.Date, 8, "Warning", "James");
            Notices n2 = new Notices(3, "Staff Meeting", "Meeting Will take place in Room 204 at 3 pm", DateTime.Now.Date, DateTime.Now.Date, 6, "Meeting", "Charley");
            Notices n3 = new Notices(4, "Notice Board", "Stop leaving spam notes on the notice board", DateTime.Now.Date, DateTime.Now.Date, 5, "Warning", "Raissa");
            Notices n4 = new Notices(5, "Management Meeting", "Meeting Will take place in Room 104 at 1 pm, only management can attend", DateTime.Now.Date, DateTime.Now.Date, 8, "Meeting", "Charley");
            NoticeList.Add(n);
            NoticeList.Add(n1);
            NoticeList.Add(n2);
            NoticeList.Add(n3);
            NoticeList.Add(n4);
            DisplayNotices();

            NoticeDGV.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            NoticeDGV.GridColor = Color.DarkGray;
            NoticeDGV.EnableHeadersVisualStyles = false;


            //These are events that are hardcoded but to test the "load data" button, comment out the code below
            //**From here**
            Events E1 = new Events(1, "Fundraiser fun!", "this happens next thursday", "cavan", DateTime.Today, "RedCross", "Funraiser", "0838087961");
            Events E2 = new Events(2, "Run", "23rd wednesday", "limerick", DateTime.Today, "run club", "Fundraiser", "083855869");
            Events E3 = new Events(3, "Swim competition", "Saturday", "UL swim pool", DateTime.Today, "Ul swim club", "Competition", "0432663959");

            events.Add(E1);
            events.Add(E2);
            events.Add(E3);
            //**To here**


            //calls the display function
            DisplayEvents();

            MemberInfo m1 = new MemberInfo(1, "raissap", "Raissa", "Pululu", "raissa@gmail.com", 0894957871, "Limerick", 20);
            MemberInfo m2 = new MemberInfo(2, "charleyr", "Charley", "Rutledge", "charley@gmail.com", 011, "Limerick", 26);
            MemberInfo m3 = new MemberInfo(3, "jamess", "James", "Sherlock", "james@gmail.com", 087, "Limerick", 22);

            MemberList.Add(m1);
            MemberList.Add(m2);
            MemberList.Add(m3);
            DisplayMembers();
        }

        private void DisplayMembers()
        {
            dataGridView2.Columns.Clear();
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = MemberList;

            dataGridView2.Columns[0].HeaderText = "Member ID";
            dataGridView2.Columns[1].HeaderText = "Username";
            dataGridView2.Columns[2].HeaderText = "First Name";
            dataGridView2.Columns[3].HeaderText = "Surname";
            dataGridView2.Columns[4].HeaderText = "Email";
            dataGridView2.Columns[5].HeaderText = "Phone";
            dataGridView2.Columns[6].HeaderText = "Address";
            dataGridView2.Columns[7].HeaderText = "Age";

            DataGridViewColumn column = dataGridView2.Columns[5];
            column.Width = 110;

            DataGridViewColumn column1 = dataGridView2.Columns[2];
            column1.Width = 182;
        }
        private void DisplayNotices()
        {
            NoticeDGV.Columns.Clear();
            NoticeDGV.DataSource = null;

            NoticeDGV.DataSource = NoticeList;
            NoticeDGV.Columns["id"].HeaderText = "Notice ID";
            NoticeDGV.Columns["title"].HeaderText = "Title";
            NoticeDGV.Columns["Text"].HeaderText = "Text";
            NoticeDGV.Columns["DatePosted"].HeaderText = "Date Posted";
            NoticeDGV.Columns["DateOf"].HeaderText = "Date Of";
            NoticeDGV.Columns["importance"].HeaderText = "Importance";
            NoticeDGV.Columns["type"].HeaderText = "Type";
            NoticeDGV.Columns["PostedBy"].HeaderText = "Posted By";

            DataGridViewColumn column = NoticeDGV.Columns[5];
            column.Width = 110;

            DataGridViewColumn column1 = NoticeDGV.Columns[2];
            column1.Width = 182;

            
        }
        private void button2_Click(object sender, EventArgs e) //ADD BUTTON
        {
            Notices noticedetails = new Notices();
            var NoticeForm = new AddNotice()
            {
                AddNote = true,
            };

            DialogResult SelectedButton = NoticeForm.ShowDialog();

            if (SelectedButton == DialogResult.OK)
            {
                noticedetails = NoticeForm.Notice;
                NoticeList.Add(noticedetails);

                NoticeDGV.DataSource = null;
                NoticeDGV.DataSource= NoticeList;
                DisplayNotices();
            }
        }
        private void Edit_Click(object sender, EventArgs e)
        {
            var NoticeForm = new AddNotice()
            {
                AddNote = false,
                Notice = SelectedNotice,
            };
            DialogResult result = NoticeForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                SelectedNotice = NoticeForm.Notice;
            }
            DisplayNotices();

        }

        private void NoticeDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

            if (e.RowIndex >= 0)
            {
                SelectedNotice = (Notices)NoticeDGV.CurrentRow.DataBoundItem;

                DataGridViewRow dgvrow = NoticeDGV.Rows[e.RowIndex];
                InfoTxtBox.Text = dgvrow.Cells[2].Value.ToString();
                IDLabel.Text = dgvrow.Cells[0].Value.ToString();
                NoticeGroupBox.Text = dgvrow.Cells[1].Value.ToString();
                label9.Text = "-" + dgvrow.Cells[7].Value.ToString();
             
            }
        }
        private void deletebtn_Click(object sender, EventArgs e)
        {
            DialogResult result =
            MessageBox.Show
            ($"Are You sure you want to Delete {SelectedNotice.Title}? ", "Confirmation Required",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                NoticeList.Remove(SelectedNotice);
                DisplayNotices();
            }
        }
        
        private void button4_Click(object sender, EventArgs e) //Copy
        {
            SelectedNotice = (Notices)NoticeDGV.CurrentRow.DataBoundItem;
            DialogResult result =

            MessageBox.Show($"Copy {SelectedNotice.Title}?",
            "Confirm Copy",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Notices n = (Notices)SelectedNotice.Clone();
                n.ID = NoticeList.Count() + 1;
                NoticeList.Add(n);
            }
            DisplayNotices();
        }
        public static void writeDataToFileNotice(List<Notices> l, string curFile1)
        {

            FileInfo fInfo = new FileInfo(curFile1);
            FileStream NoticeFile;

            if (fInfo.Exists)
            {
                NoticeFile = new FileStream(curFile1, FileMode.Truncate, FileAccess.Write);
                MessageBox.Show("found file " + fInfo.FullName);
            }
            else
            {
                NoticeFile = new FileStream(curFile1, FileMode.Create, FileAccess.Write);
                MessageBox.Show("created file " + fInfo.FullName);
            }

            BinaryFormatter bformatter = new BinaryFormatter();

            try
            {
                bformatter.Serialize(NoticeFile, l);
            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Exception caught.", e);
            }

            NoticeFile.Close();

            Console.WriteLine("Notice table data has been written to file");
        }
        public static void ReadDatafromFileNotice(ref List<Notices> l, string curFile1)
        {
            List<Notices> temp = new List<Notices>();

            FileInfo fInfo = new FileInfo(curFile1);
            FileStream EFile;

            if (fInfo.Exists)
                {
                    EFile = new FileStream(curFile1, FileMode.Open, FileAccess.Read);
                    MessageBox.Show("found file for read " + fInfo.FullName);
                    BinaryFormatter bformatter = new BinaryFormatter();
                    try
                    {
                        temp = (List<Notices>)bformatter.Deserialize(EFile);
                        l = temp;
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show("{0} Exception caught." + e);
                    }
                    EFile.Close();
                }
            else
                {
                    MessageBox.Show("ERROR CANT FIND FILE " + fInfo.FullName);
                }
            MessageBox.Show("Notice Data Has Been Loaded");
        }

        private void button3_Click(object sender, EventArgs e) //Save Button
        {
            writeDataToFile(events, curFile);
            writeDataToFileNotice(NoticeList, curFile1);
        }
        private void Loadbtnmain_Click(object sender, EventArgs e) //Load Button
        {
            ReadDatafromFile(ref events, curFile);
            DisplayEvents();
            ReadDatafromFileNotice(ref NoticeList, curFile1);
            DisplayNotices();

        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            //selects the event that the user has clicked on
            selectedEvent = (Events)dataGridView1.CurrentRow.DataBoundItem;

            //A pop up box asks if you want to delete the event that is identified by the title
            DialogResult result =
           MessageBox.Show($"Delete{selectedEvent.EventTitle }?",
     "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                //if result is yes then remove the selected event and display
                events.Remove(selectedEvent);
                DisplayEvents();

            }
        }

        private void btnCopy_Click_1(object sender, EventArgs e)
        {
            //selects the event that the user has clicked on
            selectedEvent = (Events)dataGridView1.CurrentRow.DataBoundItem;

            //A pop up box asks if you want to copy the event that is identified by the title
            DialogResult result =
           MessageBox.Show($"Copy{selectedEvent.EventTitle }?",
     "Confirm copy", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                //creates a shallow copy of the event and inserts it back into the datagridview
                Events a = (Events)selectedEvent.Clone();
                a.EventID = events.Count + 1;
                events.Add(a);
                //displays the copied event
                DisplayEvents();

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //selects the event that the user has clicked on
            selectedEvent = (Events)dataGridView1.CurrentRow.DataBoundItem;
            // creates a variable called modify event that will allow the user
            //to change an event already selected and as long as the "AddEvent" isnt selected
            //will run the modify version of the events form
            var ModifyEvent = new EventForm()
            {
                AddEvent = false,
                Event = selectedEvent,
            };


            //adds the modified event to the datagrid
            DialogResult result = ModifyEvent.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedEvent = ModifyEvent.Event;
                DisplayEvents();
            }
        }

        private void btnNewEvent_Click_1(object sender, EventArgs e)
        {
            //new event called event details
            Events EventDetails = new Events();

            //allows access to events form
            //AddEvent is set to true 
            var EventsForm = new EventForm()
            {
                AddEvent = true
            };


            //shows the events form and if the okay button is selected, it adds the new event details
            //to the datagrid view
            DialogResult selectedButton = EventsForm.ShowDialog();

            if (selectedButton == DialogResult.OK)
            {
                EventDetails = EventsForm.Event;

                events.Add(EventDetails);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = events;

            }
        }

       

        public static void writeDataToFile(List<Events> l, string curFile)
        {

            FileInfo fInfo = new FileInfo(curFile);
            FileStream EventFile;

            // if the file exits it displays the message   "found file" and cannot be re written
            //else it write to the file and displays "created file"
            if (fInfo.Exists)
            {
                EventFile = new FileStream(curFile, FileMode.Truncate, FileAccess.Write);
                MessageBox.Show("found file " + fInfo.FullName);
            }
            else
            {
                EventFile = new FileStream(curFile, FileMode.Create, FileAccess.Write);
                MessageBox.Show("created file " + fInfo.FullName);
            }

            BinaryFormatter bformatter = new BinaryFormatter();

            try
            {
                bformatter.Serialize(EventFile, l);
            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Exception caught.", e);
            }

            EventFile.Close();

            Console.WriteLine("data written to file");


        }


       
       

        //read data from file function
        public static void ReadDatafromFile(ref List<Events> l, string curFile)
        {
            //creates a new list called temp
            List<Events> temp = new List<Events>();

            FileInfo fInfo = new FileInfo(curFile);
            FileStream EFile;

            //if the file exists then the file is read and deserialized 
            if (fInfo.Exists)
            {
                EFile = new FileStream(curFile, FileMode.Open, FileAccess.Read);
                MessageBox.Show("found file for read " + fInfo.FullName);
                BinaryFormatter bformatter = new BinaryFormatter();
                try
                {
                    temp = (List<Events>)bformatter.Deserialize(EFile);
                    l = temp;

                }
                catch (Exception e)
                {
                    MessageBox.Show("{0} Exception caught." + e);
                }
                EFile.Close();
            }
            else
            {
                MessageBox.Show("ERROR CANT FIND FILE " + fInfo.FullName);
            }

            MessageBox.Show("data read");
        }
      
        private void btnSave_Click_1(object sender, EventArgs e)
        {
            writeDataToFile(events, curFile);
        }

        //loads data from file and displays events
        private void btnLoadData_Click_1(object sender, EventArgs e)
        {
            ReadDatafromFile(ref events, curFile);
            DisplayEvents();
        }



        private void InfoTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }
        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void btnNewEvent_Click(object sender, EventArgs e)
        {

        }

        private void btnCopy_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            MemberInfo member = new MemberInfo();
            RegisterForm registerForm = new RegisterForm(member);
            DialogResult selectedButton = registerForm.ShowDialog();
            if (selectedButton == DialogResult.OK)
            {
                MemberList.Add(member);
            }
        }
    }
}
