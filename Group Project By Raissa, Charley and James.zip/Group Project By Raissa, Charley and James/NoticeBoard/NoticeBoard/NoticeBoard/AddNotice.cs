﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoticeBoard
{
    public partial class AddNotice : Form
    {
        public AddNotice()
        {
            InitializeComponent();
        }
        public bool AddNote { get; set; }

        public Notices Notice { get; set; }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (AddNote)
            {
                this.Text = "Add Notice";
            }
            else
            {
                this.Text = "View Notice";
                this.DisplayNotice();
            }
        }
        private void ANAdd_Click(object sender, EventArgs e)
        {
            if (AddNote)
            {
                Notice = new Notices();
            }
            Notice.ID = Convert.ToInt32(textBox1.Text);
            Notice.Title = textBox2.Text;
            Notice.DatePosted = dateTimePicker1.Value.Date;
            Notice.DateOf = dateTimePicker2.Value.Date;
            Notice.Importance = Convert.ToInt32(textBox3.Text);
            Notice.Type = textBox4.Text;
            Notice.Text = richTextBox1.Text;
            Notice.PostedBy = "James";

            this.DialogResult = DialogResult.OK;
        }
        private void DisplayNotice()
        {
            textBox1.Text = Convert.ToString(Notice.ID);
            textBox2.Text = Notice.Title;
            dateTimePicker1.Value = Notice.DatePosted;
            dateTimePicker2.Value = Notice.DateOf;
            textBox3.Text = Convert.ToString(Notice.Importance);
            textBox4.Text = Notice.Type;
            richTextBox1.Text = Notice.Text;
        }   

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ANCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
