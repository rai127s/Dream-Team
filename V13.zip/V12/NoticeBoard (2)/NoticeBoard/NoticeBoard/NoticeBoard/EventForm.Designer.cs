﻿
namespace NoticeBoard
{
    partial class EventForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtEventTitle = new System.Windows.Forms.TextBox();
            this.txtEventDetails = new System.Windows.Forms.TextBox();
            this.txtEventLocation = new System.Windows.Forms.TextBox();
            this.dtpDateSubmitted = new System.Windows.Forms.DateTimePicker();
            this.txtEventHost = new System.Windows.Forms.TextBox();
            this.txtEventType = new System.Windows.Forms.TextBox();
            this.txtHostContactInfo = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(28, 19);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Event title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(28, 46);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Event details";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(28, 70);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Event Location";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(28, 97);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(28, 123);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Event Host";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(28, 149);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Event Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(13, 175);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Host Contact info";
            // 
            // txtEventTitle
            // 
            this.txtEventTitle.BackColor = System.Drawing.SystemColors.Window;
            this.txtEventTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEventTitle.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEventTitle.Location = new System.Drawing.Point(143, 19);
            this.txtEventTitle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEventTitle.Name = "txtEventTitle";
            this.txtEventTitle.Size = new System.Drawing.Size(105, 17);
            this.txtEventTitle.TabIndex = 9;
            // 
            // txtEventDetails
            // 
            this.txtEventDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEventDetails.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEventDetails.Location = new System.Drawing.Point(143, 46);
            this.txtEventDetails.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEventDetails.Name = "txtEventDetails";
            this.txtEventDetails.Size = new System.Drawing.Size(192, 17);
            this.txtEventDetails.TabIndex = 10;
            // 
            // txtEventLocation
            // 
            this.txtEventLocation.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEventLocation.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEventLocation.Location = new System.Drawing.Point(143, 69);
            this.txtEventLocation.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEventLocation.Name = "txtEventLocation";
            this.txtEventLocation.Size = new System.Drawing.Size(105, 17);
            this.txtEventLocation.TabIndex = 11;
            // 
            // dtpDateSubmitted
            // 
            this.dtpDateSubmitted.CalendarFont = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtpDateSubmitted.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtpDateSubmitted.Location = new System.Drawing.Point(137, 94);
            this.dtpDateSubmitted.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpDateSubmitted.MinDate = new System.DateTime(2022, 4, 22, 0, 0, 0, 0);
            this.dtpDateSubmitted.Name = "dtpDateSubmitted";
            this.dtpDateSubmitted.Size = new System.Drawing.Size(211, 24);
            this.dtpDateSubmitted.TabIndex = 12;
            this.dtpDateSubmitted.Value = new System.DateTime(2022, 4, 22, 0, 0, 0, 0);
            // 
            // txtEventHost
            // 
            this.txtEventHost.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEventHost.Location = new System.Drawing.Point(143, 123);
            this.txtEventHost.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEventHost.Name = "txtEventHost";
            this.txtEventHost.Size = new System.Drawing.Size(106, 24);
            this.txtEventHost.TabIndex = 13;
            // 
            // txtEventType
            // 
            this.txtEventType.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEventType.Location = new System.Drawing.Point(143, 149);
            this.txtEventType.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEventType.Name = "txtEventType";
            this.txtEventType.Size = new System.Drawing.Size(106, 24);
            this.txtEventType.TabIndex = 14;
            // 
            // txtHostContactInfo
            // 
            this.txtHostContactInfo.Font = new System.Drawing.Font("Arial Nova Cond", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtHostContactInfo.Location = new System.Drawing.Point(143, 175);
            this.txtHostContactInfo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtHostContactInfo.Name = "txtHostContactInfo";
            this.txtHostContactInfo.Size = new System.Drawing.Size(106, 24);
            this.txtHostContactInfo.TabIndex = 15;
            // 
            // btnCreate
            // 
            this.btnCreate.Font = new System.Drawing.Font("Arial Nova Cond", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCreate.Location = new System.Drawing.Point(60, 243);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(78, 24);
            this.btnCreate.TabIndex = 16;
            this.btnCreate.Text = "&Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Arial Nova Cond", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnClose.Location = new System.Drawing.Point(230, 243);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(78, 24);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "Exit";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.button2_Click);
            // 
            // EventForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(355, 270);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.txtHostContactInfo);
            this.Controls.Add(this.txtEventType);
            this.Controls.Add(this.txtEventHost);
            this.Controls.Add(this.dtpDateSubmitted);
            this.Controls.Add(this.txtEventLocation);
            this.Controls.Add(this.txtEventDetails);
            this.Controls.Add(this.txtEventTitle);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.ForeColor = System.Drawing.SystemColors.InfoText;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "EventForm";
            this.Text = "EventForm";
            this.Load += new System.EventHandler(this.EventForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtEventTitle;
        private System.Windows.Forms.TextBox txtEventDetails;
        private System.Windows.Forms.TextBox txtEventLocation;
        private System.Windows.Forms.DateTimePicker dtpDateSubmitted;
        private System.Windows.Forms.TextBox txtEventHost;
        private System.Windows.Forms.TextBox txtEventType;
        private System.Windows.Forms.TextBox txtHostContactInfo;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnClose;
    }
}