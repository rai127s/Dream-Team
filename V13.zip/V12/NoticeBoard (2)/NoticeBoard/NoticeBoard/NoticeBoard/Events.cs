﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoticeBoard
{
    [Serializable]
    public class Events : ICloneable
    {
        protected internal int EventID { get ; set; }
        public string EventTitle { get; set; }
        public string EventText { get; set; }
        public string EventLocation { get; set; }
        public DateTime DatePosted { get; set; }
        public string EventHost { get; set; }
        public string EventType { get; set; }
        public string HostContact { get; set; }

        public Events() { }

        public Events(int EventID, string EventTitle, string EventText, string EventLocation, DateTime DatePosted, string EventHost, string EventType, string HostContact)
        {
            this.EventID = EventID;
            this.EventTitle = EventTitle;
            this.EventText = EventText;
            this.EventLocation = EventLocation;
            this.DatePosted = DatePosted;
            this.EventHost = EventHost;
            this.EventType = EventType;
            this.HostContact = HostContact;
        }
        public object Clone()
        {
            return MemberwiseClone();

        }

    }
}